#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/common.sh"

# 等待 Android 设置提供程序和厂商电池服务完成启动。
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 5
done
sleep 10

while true; do
  apply_state
  sleep 15
done
