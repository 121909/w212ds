#!/system/bin/sh

ui_print "***************************************"
ui_print " 中兴充电分离自动控制 v1.4.0"
ui_print "***************************************"
ui_print "默认阈值：70%"
ui_print "采用轻量轮询与状态缓存。"
ui_print "仅在 USB 供电接入时检测并控制充电分离。"
ui_print "重启后点击模块的“执行”按钮，"
ui_print "使用音量＋/－选择 50% 至 90% 阈值。"

if [ "$(getprop ro.vendor.feature.zte_feature_support_charge_separation)" != "true" ]; then
  ui_print "! 警告：未检测到中兴原生充电分离功能"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/common.sh" 0 0 0755
