#!/system/bin/sh

# 卸载模块时关闭充电分离，使设备恢复正常充电。
settings put global charge_separation_switch 0 2>/dev/null
