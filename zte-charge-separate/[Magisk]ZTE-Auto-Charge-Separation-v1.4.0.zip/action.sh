#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/common.sh"

read_threshold

save_threshold() {
  printf '# 可选值：50、60、70、80、90\nTHRESHOLD=%s\n' "$THRESHOLD" > "$CONFIG"
  apply_state
}

echo "======================================="
echo " 中兴充电分离阈值设置"
echo "======================================="
echo "当前阈值：${THRESHOLD}%"
echo "音量＋：提高 10%"
echo "音量－：降低 10%"
echo "停止按键 6 秒后自动保存并退出"
echo ""

while true; do
  EVENT="$(timeout 6 getevent -ql 2>/dev/null | grep -m 1 -E 'KEY_VOLUME(UP|DOWN).*DOWN')"

  case "$EVENT" in
    *KEY_VOLUMEUP*DOWN*)
      if [ "$THRESHOLD" -lt 90 ]; then
        THRESHOLD=$((THRESHOLD + 10))
      fi
      save_threshold
      echo "已选择：${THRESHOLD}%（音量＋提高，音量－降低）"
      ;;
    *KEY_VOLUMEDOWN*DOWN*)
      if [ "$THRESHOLD" -gt 50 ]; then
        THRESHOLD=$((THRESHOLD - 10))
      fi
      save_threshold
      echo "已选择：${THRESHOLD}%（音量＋提高，音量－降低）"
      ;;
    *)
      break
      ;;
  esac
done

save_threshold
echo ""
echo "设置已保存：${THRESHOLD}%"
echo "达到或高于 ${THRESHOLD}%：开启充电分离"
echo "低于 ${THRESHOLD}%：关闭充电分离"
