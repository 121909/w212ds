#!/system/bin/sh

MODDIR="${0%/*}"
CONFIG="$MODDIR/config.conf"
LOGFILE="$MODDIR/module.log"
CAPACITY_NODE="/sys/class/power_supply/battery/capacity"
USB_ONLINE_NODE="/sys/class/power_supply/usb/online"
SETTING_KEY="charge_separation_switch"
LAST_USB_STATE="unknown"
LAST_DESIRED_STATE="unknown"
LAST_THRESHOLD="unknown"
LOW_WATCHDOG_TICKS=0

read_threshold() {
  THRESHOLD=70
  if [ -r "$CONFIG" ]; then
    while IFS='=' read -r key value; do
      if [ "$key" = "THRESHOLD" ]; then
        case "$value" in
          50|60|70|80|90) THRESHOLD="$value" ;;
        esac
      fi
    done < "$CONFIG"
  fi
}

read_capacity() {
  CAPACITY=""
  [ -r "$CAPACITY_NODE" ] || return 1
  IFS= read -r CAPACITY < "$CAPACITY_NODE" 2>/dev/null || return 1
  case "$CAPACITY" in
    ''|*[!0-9]*) return 1 ;;
  esac
  return 0
}

read_usb_state() {
  USB_STATE=0
  [ -r "$USB_ONLINE_NODE" ] || return 1
  IFS= read -r value < "$USB_ONLINE_NODE" 2>/dev/null || return 1
  [ "$value" = "1" ] && USB_STATE=1
  return 0
}

set_switch() {
  DESIRED="$1"
  CURRENT="$(settings get global "$SETTING_KEY" 2>/dev/null)"
  if [ "$CURRENT" != "$DESIRED" ]; then
    settings put global "$SETTING_KEY" "$DESIRED"
    return 0
  fi
  return 1
}

log_event() {
  if [ -f "$LOGFILE" ]; then
    LOG_SIZE="$(stat -c '%s' "$LOGFILE" 2>/dev/null)"
    case "$LOG_SIZE" in
      ''|*[!0-9]*) LOG_SIZE=0 ;;
    esac
    [ "$LOG_SIZE" -ge 65536 ] && : > "$LOGFILE"
  fi
  printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOGFILE"
}

apply_state() {
  read_usb_state

  if [ "$USB_STATE" != "1" ]; then
    # 未接入 USB 时只在状态刚变化或进程刚启动时确认关闭一次。
    if [ "$LAST_USB_STATE" != "0" ]; then
      if set_switch 0; then
        log_event "usb=disconnected switch=0"
      fi
    fi
    LAST_USB_STATE=0
    LAST_DESIRED_STATE=0
    LAST_THRESHOLD="unknown"
    LOW_WATCHDOG_TICKS=0
    return 0
  fi

  read_threshold
  read_capacity || return 1

  if [ "$CAPACITY" -ge "$THRESHOLD" ]; then
    DESIRED=1
  else
    DESIRED=0
  fi

  NEED_RECONCILE=0
  if [ "$LAST_USB_STATE" != "1" ] || \
     [ "$LAST_DESIRED_STATE" != "$DESIRED" ] || \
     [ "$LAST_THRESHOLD" != "$THRESHOLD" ]; then
    NEED_RECONCILE=1
    LOW_WATCHDOG_TICKS=0
  elif [ "$DESIRED" = "1" ]; then
    # 达到阈值后每轮检查原生开关，防止厂商服务自动关闭。
    NEED_RECONCILE=1
  else
    # 低于阈值时每 5 分钟复核一次，平时只读取 sysfs 节点。
    LOW_WATCHDOG_TICKS=$((LOW_WATCHDOG_TICKS + 1))
    if [ "$LOW_WATCHDOG_TICKS" -ge 20 ]; then
      NEED_RECONCILE=1
      LOW_WATCHDOG_TICKS=0
    fi
  fi

  if [ "$NEED_RECONCILE" = "1" ] && set_switch "$DESIRED"; then
    log_event "usb=connected capacity=$CAPACITY threshold=$THRESHOLD switch=$DESIRED"
  fi

  LAST_USB_STATE=1
  LAST_DESIRED_STATE="$DESIRED"
  LAST_THRESHOLD="$THRESHOLD"
}
