#!/system/bin/sh

MODDIR="${0%/*}"
. "$MODDIR/common.sh"
TH_LATCH=0
FULL_LATCH=0

# Wait for Android to finish booting. Single loop, two cadences:
# - every 3s: watch insertion events (usb/online 0 -> 1) and decide once
#   (PC / charger mode 1). Unplug is handled by the system.
# - every ~30s (10 x 3s): threshold mode state machine (charger mode 2),
#   lightweight polling at a 30s interval.
# While the SukiSU module switch is off ($MODDIR/disable exists), all
# separation logic is skipped: plugging a charger does nothing. The file is
# re-checked every tick, so flipping the switch back on resumes control
# without a reboot.
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 5
done
sleep 10

prev="$(cat "$USB_ONLINE_NODE" 2>/dev/null)"
tick=0
while true; do
  if [ -e "$MODDIR/disable" ]; then
    # Module switch off: no decisions, but keep tracking plug state so a
    # later re-enable sees a fresh insertion edge.
    prev="$(cat "$USB_ONLINE_NODE" 2>/dev/null)"
    sleep 3
    continue
  fi
  cur="$(cat "$USB_ONLINE_NODE" 2>/dev/null)"
  if [ "$prev" != "1" ] && [ "$cur" = "1" ]; then
    apply_once
  fi
  if [ "$prev" = "1" ] && [ "$cur" != "1" ]; then
    # Unplug resets both latches here, ahead of threshold_tick, so this is the
    # only place that can record the event. Always log: the switch itself
    # normally self-resets on power removal, so set_switch is usually a no-op
    # here.
    TH_LATCH=0
    FULL_LATCH=0
    set_switch 0
    log "unplug sep=0 latch=0"
  fi
  sleep 3
done
